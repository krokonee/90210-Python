import time # Для задержек (паузa)
from threading import Thread, Lock  # Для создания параллельных задач (потоков) и управления доступом к общим ресурсам
import sys # Для прямого вывода в консоль
import pyglet 

lock = Lock()

mus = pyglet.resource.media("90210.mp3") #добавление аудиофайла
mus.play()

pyglet.app.run

def animate_text(text, delay=0.1): 
#Функция для анимированного вывода текста.
#Выводит текст символ за символом с небольшой задержкой.
    with lock: # Захватываем "замок", чтобы другой поток не начал писать, пока этот не закончит.
        for char in text:
            sys.stdout.write(char) # Выводим один символ
            sys.stdout.flush()     # Немедленно показываем его в консоли
            time.sleep(delay)      # Ждем немного перед следующим символом
        print()

def sing_lyric(lyric, delay, speed):
    time.sleep(delay)
    animate_text(lyric, speed)

def sing_song():
    #строки песни и скорость печати 
    lyrics =  [
        ("My granny called, she said", 0.06),
        ("'Travvy, you work too hard", 0.05),
        ("I′m worried you forget about me'", 0.06),
        ("Ball Ball Ball", 0.09),
        ("I'm falling in and out of clouds,", 0.06),
        ("don′t worry, I'ma get it, Granny", 0.06),
        ("What happened? Now my daddy happy", 0.06),
        ("Mama called me up, that money coming and she love me", 0.06),
        ("I done made it now,", 0.06),
        ("I done found life′s meaning now", 0.06),
        ("All them days her heart'd break", 0.06)
    
    ]
    delays = [1.2, 1.5, 1.6, 1.8, 7.7, 7.8, 13.4, 14.3, 14.4, 14.5, 14.6] #время вывода текста
    
    threads = [] #создает пустой список для хранения всех потоков.
    for i in range(len(lyrics)): #цикл проходит по каждой строке в lyrics
        lyric, speed = lyrics[i] #извлекает текст и скорость для текущей строки
        t = Thread(target=sing_lyric, args=(lyric, delays[i], speed))
        threads.append(t)
        t.start()
    #запускает поток, позволяя sing_lyric выполняться в фоновом режиме параллельно с другими строками.

    for thread in threads:
        thread.join() 
    #главный поток ждет, пока все запущенные потоки завершат свою работу, прежде чем продолжить.

if __name__ == "__main__":
    sing_song()
    #убеждается, что функция sing_song() вызывается только при прямом запуске скрипта.
